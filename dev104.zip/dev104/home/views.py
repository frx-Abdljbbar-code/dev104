from django.shortcuts import render, get_object_or_404, redirect
from .forms import UserRegistrationForm, ContactUsForm
from django.contrib.auth import login, authenticate
from .models import HomeContent
from pro_file.models import Profile
from django.contrib.auth.models import User
from django.http import HttpResponseRedirect
from django.contrib.auth.decorators import login_required

def home(request):
    prof = Profile.objects.all()
    contenthome = HomeContent.objects.all()
    context = {
       'prof': prof,
       'contenthome': contenthome
    }
    return render(request, 'home/home.html', context)
@login_required
def Contact(request):
    form = ContactUsForm(request.POST or None)
    if request.method == "POST":
        if form.is_valid():
            new_form = form.save(commit=False)
            new_form.user = request.user
            new_form.save()
            return HttpResponseRedirect('/')
        else:
            form = ContactUsForm(request.POST or None)
    context = {
        'form': form,
    }
    return render(request, 'home/contact.html', context)

def signup(request):
    form = UserRegistrationForm(request.POST or None)
    if request.method == 'POST':
        if form.is_valid():
            new_form = form.save(commit=False)
            new_form.user = request.user
            new_form.save()

            id = form.cleaned_data.get('id')
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password1')
            user = authenticate(username=username, password=password)
            login(request, user)
            print(request, user, id)
            return HttpResponseRedirect('/')

        else:
            print("Your Form is Not Valid!\n Error!!")
    context = {
        'form': form,
    }
    return render(request, 'registration/signup.html', context)
