from django.urls import path
from post.views import *

app_name = 'post'

urlpatterns = [
    path('post/', post, name='post'),
    path('<int:id>/', detail, name='detail')
]
