from django.shortcuts import render,get_object_or_404,redirect
# Create your views here.
def post(request):
    posts = Post.objects.all()
    context = {'posts': posts}
    return render(request,'post/post.html', context)

def detail():
    pass
