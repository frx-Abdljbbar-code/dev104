from django.contrib import admin
from .models import Profile


admin.site.site_header = 'Developement Digital Dashboard'
admin.site.site_title = 'Dev104'
admin.site.index_title = 'Admin Dashboard'
admin.site.register(Profile)
